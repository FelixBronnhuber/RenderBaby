pub fn foo() {
    todo!();
}
