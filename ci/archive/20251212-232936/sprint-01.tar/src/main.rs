use control_plane::App;

fn main() {
    let app = App::new();
    app.show();
}
