use serde::{Deserialize, Serialize};

#[derive(Serialize, Deserialize)]
#[allow(unused)]
pub(crate) struct ProxyCamera {}
