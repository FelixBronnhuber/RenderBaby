#[cfg(test)]
mod some_test {
    #[test]
    fn it_works() {}
}
