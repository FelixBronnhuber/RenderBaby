use std::sync::{Arc, Mutex};
use std::sync::atomic::AtomicBool;
use crate::frame_provider::*;

pub struct FrameBuffer {
    latest_frame: Arc<Mutex<Option<Frame>>>,
    worker_thread: Arc<Mutex<Option<std::thread::JoinHandle<()>>>>,
    stop_flag: Arc<AtomicBool>,
}

impl FrameBuffer {
    pub fn provide(&self, provider: Box<dyn FrameProvider>) {
        // create new thread with provider
    }

    pub fn stop(&self) {
        self.stop_flag
            .store(true, std::sync::atomic::Ordering::SeqCst);
    }

    pub fn is_running(&self) -> bool {
        false
    }

    pub fn clear(&self) {
        self.latest_frame.lock().unwrap().take();
    }

    pub fn try_recv(&self) -> Option<Frame> {
        self.latest_frame.lock().unwrap().take()
    }
}
