pub mod camera;
pub mod geometric_object;
pub mod light_source;
pub mod material;
pub mod mesh;
pub mod sphere;
pub mod tests;
pub mod tri_geometry;
