use engine_wgpu_wrapper::RenderOutput;

#[allow(dead_code)]
pub fn export_img_png(_path: String, _render: RenderOutput) {
    todo!()
}
