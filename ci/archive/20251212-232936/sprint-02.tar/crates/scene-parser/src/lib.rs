///This is for the scene file parser
#[cfg(test)]
mod tests {

    #[test]
    fn it_works() {
        let result = 4;
        assert_eq!(result, 4);
    }
    #[test]
    fn parse_json() {}
}
