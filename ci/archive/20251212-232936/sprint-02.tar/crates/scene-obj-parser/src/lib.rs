// put own code for obj parser here!
#[cfg(test)]
mod tests {

    #[test]
    fn it_works() {
        let result = 4;
        assert_eq!(result, 4);
    }
    #[test]
    fn parse() {}
}
