pub mod _scene; // TODO: Rename _scene is a temporary name
pub mod geometric_object;
pub mod scene_engine_adapter;
pub mod scene_graph;
