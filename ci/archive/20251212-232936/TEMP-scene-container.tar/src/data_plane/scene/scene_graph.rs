use scene_objects::jsonables::{camera::Camera, light::Light};

use scene_objects::{mesh::Mesh, sphere::Sphere, tri_geometry::TriGeometry};

/// The scene graphs holds all elements of the scene
pub(crate) struct SceneGraph {
    pub tri_geometries: Vec<TriGeometry>,
    pub spheres: Vec<Sphere>,
    pub meshes: Vec<Mesh>,
    pub light_sources: Vec<Light>,
    pub camera: Camera,
}

#[allow(dead_code)]
impl SceneGraph {
    pub fn new() -> Self {
        //! ## Returns
        //! a new scene graph with emtpy objects, light_sources, and a default Camera
        Self {
            tri_geometries: Vec::new(),
            spheres: Vec::new(),
            meshes: Vec::new(),
            light_sources: Vec::new(),
            camera: Camera::default(),
        }
    }
}
