use std::collections::HashMap;
use std::fs;
use std::fs::File;
use std::path::Path;

use glam::Vec3;
use scene_objects::{
    jsonables::camera::Camera,
    jsonables::object::Object,
    jsonables::light::{Light, LightType},
    tri_geometry::TriGeometry,
};
use serde::{Deserialize, Serialize};
use scene_objects::jsonables::container::Container;
use crate::data_plane::scene::{render_scene::Scene};

#[derive(Serialize, Deserialize, Debug)]
struct FileColor {
    r: f32,
    g: f32,
    b: f32,
    a: Option<f32>, //ungenutzt
}

#[derive(Serialize, Deserialize, Debug, Clone)]
struct Vec3d {
    x: f32,
    y: f32,
    z: f32,
}

impl From<Vec3> for Vec3d {
    fn from(v: Vec3) -> Vec3d {
        Vec3d {
            x: v.x,
            y: v.y,
            z: v.z,
        }
    }
}

#[allow(dead_code)]
pub fn serialize_scene(sc: &mut Scene) {}

#[derive(Debug)]
pub enum SceneParseError {
    NotAFile,
}

pub fn parse_scene(scene_path: String) -> Result<Scene, SceneParseError> {
    // TODO: please add proper error handling!!!
    let scene_path = Path::new(&scene_path);
    if !scene_path.is_file() {
        return Err(SceneParseError::NotAFile);
    }
    let _json_content = fs::read_to_string(scene_path);
    // let read = serde_json::from_str::<SceneFile>(&json_content).unwrap();
    // transform_to_scene(read)
    todo!("Fix serde_json");
}
