use serde::{Deserialize, Serialize};
use crate::jsonables::xyz::XYZ;

#[derive(Serialize, Deserialize, Clone, Debug)]
pub struct Object {
    pub name: String,
    pub path: String,
    pub scale: XYZ,
    pub rotation: XYZ,
    pub translation: XYZ,
}

impl Default for Object {
    fn default() -> Self {
        Self {
            name: "".to_string(),
            path: "".to_string(),
            scale: XYZ::default(),
            rotation: XYZ::default(),
            translation: XYZ::default(),
        }
    }
}
