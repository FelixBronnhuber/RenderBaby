use std::fmt::{Formatter, Result as FmtResult, Display};
use serde::{Deserialize, Serialize};
use crate::jsonables::resolution::Resolution;
use crate::jsonables::xyz::XYZ;

/// Camera that is used to render scenes
#[allow(dead_code)]
#[derive(Serialize, Deserialize, Clone, Debug)]
pub struct Camera {
    pub position: XYZ,
    pub rotation: XYZ, // fov: f32 ?
    pub fov: f32,
    pub resolution: Resolution,
}

impl Camera {
    pub fn new(position: XYZ, rotation: XYZ, fov: f32, resolution: Resolution) -> Self {
        //! Constructor for new Camera
        Self {
            position,
            rotation,
            fov,
            resolution,
        }
    }
}

impl Default for Camera {
    fn default() -> Self {
        Self {
            position: XYZ::default(),
            rotation: XYZ::default(),
            fov: 1.0,
            resolution: Resolution::default(),
        }
    }
}

impl Display for Camera {
    fn fmt(&self, f: &mut Formatter<'_>) -> FmtResult {
        write!(f, "Camera at {:?}", self.position)
    }
}
