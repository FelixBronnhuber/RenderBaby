use serde::{Deserialize, Serialize};
use crate::jsonables::color::Color;
use crate::jsonables::xyz::XYZ;

#[derive(Serialize, Deserialize, Clone, Debug)]
pub enum LightType {
    Ambient,
    Point,
    Directional,
}

#[derive(Serialize, Deserialize, Clone, Debug)]
pub struct Light {
    pub name: String,
    pub r#type: LightType,
    pub luminosity: f32,
    pub position: XYZ,
    pub rotation: XYZ,
    pub color: Color,
}

impl Light {
    pub fn new(
        name: &str,
        r#type: LightType,
        luminosity: f32,
        position: XYZ,
        rotation: XYZ,
        color: Color,
    ) -> Self {
        Self {
            name: name.to_string(),
            r#type,
            luminosity,
            position,
            rotation,
            color,
        }
    }
}
