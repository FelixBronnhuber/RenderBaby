use serde::{Deserialize, Serialize};
use crate::jsonables::camera::Camera;
use crate::jsonables::color::Color;
use crate::jsonables::light::Light;
use crate::jsonables::object::Object;

#[derive(Serialize, Deserialize, Clone, Debug)]
pub struct Container {
    pub scene_name: String,
    pub objects: Vec<Object>,
    pub background_color: Color,
    pub camera: Camera,
    pub lights: Vec<Light>,
}
