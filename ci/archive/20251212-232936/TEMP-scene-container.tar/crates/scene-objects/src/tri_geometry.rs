use std::any::Any;

use glam::Vec3;

use crate::{geometric_object::GeometricObject, material::Material};
use crate::jsonables::object::Object;

#[allow(dead_code)]
#[derive(Debug, Clone)]
pub struct TriGeometry {
    pub triangles: Vec<Triangle>,
    pub attr: Object,
    pub file_path: String,
    pub name: String,
    pub material: Material,
}
impl GeometricObject for TriGeometry {
    fn scale(&mut self, factor: f32) {
        for tri in self.triangles.iter_mut() {
            tri.scale(factor);
        }
    }

    fn translate(&mut self, vec: Vec3) {
        for tri in self.triangles.iter_mut() {
            tri.translate(vec);
        }
    }

    fn rotate(&mut self, _vec: Vec3) {
        todo!()
    }
    fn as_any(&self) -> &dyn Any {
        self
    }
}

#[allow(dead_code)]
#[derive(Debug, Clone)]
pub struct Triangle {
    pub points: Vec<Vec3>, // todo: Probably introduces a typ for 3 3dPoints
    pub material: Option<Material>,
}

impl GeometricObject for Triangle {
    fn scale(&mut self, _factor: f32) {
        todo!()
    }

    fn translate(&mut self, vec: Vec3) /* -> &Vec<Vec3>*/
    {
        for point in &mut self.points {
            *point += vec;
        }
        //self.get_points()
    }

    fn rotate(&mut self, _vec: Vec3) {
        todo!()
    }
    fn as_any(&self) -> &dyn Any {
        self
    }
}
