use std::any::Any;

use glam::Vec3;

#[allow(dead_code)]
///Defines some basic geometric functions that all Render Objects should offer
pub trait GeometricObject {
    fn scale(&mut self, factor: f32); // TODO: scale 3d?
    fn translate(&mut self, vec: Vec3);
    fn rotate(&mut self, vec: Vec3);
    fn as_any(&self) -> &dyn Any;
}
