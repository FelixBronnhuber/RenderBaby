use std::any::Any;
use glam::Vec3;
use crate::{geometric_object::GeometricObject, material::Material, jsonables::object::Object};

#[allow(dead_code)]
#[derive(Debug)]
/// Simple Sphere defined by a 3d center and a radius
pub struct Sphere {
    center: Vec3,
    radius: f32,
    material: Material,
    color: [f32; 3],
    attr: Object,
}

impl Sphere {
    pub fn new(
        center: Vec3,
        radius: f32,
        material: Material,
        color: [f32; 3],
        attr: Object,
    ) -> Self {
        //! Constructor for new Sphere
        Self {
            center,
            radius,
            material,
            color,
            attr,
        }
    }
}

impl Default for Sphere {
    fn default() -> Self {
        Self {
            center: Vec3::default(),
            radius: 1.0,
            material: Material::default(),
            color: [1.0, 1.0, 1.0],
            attr: Object::default(),
        }
    }
}

impl GeometricObject for Sphere {
    fn scale(&mut self, factor: f32) {
        //! scales the radius of the sphere
        //! ## Parameter
        //! 'factor': scale factor
        self.radius *= factor;
        //self.radius
    }
    fn translate(&mut self, vec: Vec3) {
        //! Moves the center of the sphere
        //! ## Parameter
        //! 'vec': Translation vector as glam::Vec3
        self.center += vec;
        //self.center
    }
    fn rotate(&mut self, _vec: Vec3) {
        //! Rotates the sphere? Rly?
    }
    fn as_any(&self) -> &dyn Any {
        self
    }
}
